const Alexa = require('ask-sdk-core');

const PERMISSIONS = ['alexa::alerts:timers:skill:readwrite'];

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    async handle(handlerInput) {
        await cleanupExistingTimers(handlerInput);
        const speakOutput = 'Welcome to personal timer skill. You can set a timer by saying "set timer" followed by the duration.';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const SetTimerIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SetTimerIntent';
    },
    async handle(handlerInput) {
        const {requestEnvelope, serviceClientFactory, responseBuilder} = handlerInput;
        
        try {
            await cleanupExistingTimers(handlerInput);

            const timerSlot = Alexa.getSlot(handlerInput.requestEnvelope, 'timerDuration');
            const timerDuration = timerSlot.value; // ISO8601 duration

            // Check if duration is provided
            if (!timerDuration) {
                return responseBuilder
                    .speak('For how long would you like to set the timer?')
                    .reprompt('Please tell me the duration, for example: 5 minutes, 30 seconds, or 1 hour.')
                    .addElicitSlotDirective('timerDuration')
                    .getResponse();
            }

            // Process the duration only if we have a value
            const spokenWords = timerDuration;
            let naturalDuration = spokenWords;
            
            if (spokenWords.startsWith('PT')) {
                const number = spokenWords.replace(/[^0-9]/g, '');
                const unit = spokenWords.slice(-1);
                
                switch(unit) {
                    case 'S':
                        naturalDuration = `${number} ${number === '1' ? 'second' : 'seconds'}`;
                        break;
                    case 'M':
                        naturalDuration = `${number} ${number === '1' ? 'minute' : 'minutes'}`;
                        break;
                    case 'H':
                        naturalDuration = `${number} ${number === '1' ? 'hour' : 'hours'}`;
                        break;
                    default:
                        naturalDuration = spokenWords;
                }
            }

            const locale = requestEnvelope.request.locale || 'en-US';
            
            const timerRequest = {
                duration: timerDuration,
                timerLabel: '',
                creationBehavior: {
                    displayExperience: {
                        visibility: 'VISIBLE'
                    }
                },
                triggeringBehavior: {
                    operation: {
                        type: 'ANNOUNCE',
                        textToAnnounce: [{
                            locale: locale,
                            text: `Your timer is done`
                        }]
                    },
                    notificationConfig: {
                        playAudible: true
                    }
                }
            };

            await serviceClientFactory.getTimerManagementServiceClient().createTimer(timerRequest);
            
            return responseBuilder
                .speak(`Timer set for ${naturalDuration}.`)
                .withShouldEndSession(true)
                .getResponse();

        } catch (error) {
            console.log('Error:', error);
            if (error.statusCode === 401) {
                return responseBuilder
                    .speak('Please enable Timer permissions in the Alexa app.')
                    .withAskForPermissionsConsentCard(PERMISSIONS)
                    .withShouldEndSession(true)
                    .getResponse();
            }
            return responseBuilder
                .speak('Sorry, there was an error setting the timer. Please try again.')
                .withShouldEndSession(true)
                .getResponse();
        }
    }
};

const CancelTimerIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CancelTimerIntent';
    },
    async handle(handlerInput) {
        const {serviceClientFactory, responseBuilder} = handlerInput;

        const permissionsCheck = await checkTimerPermissions(handlerInput);
        if (!permissionsCheck.hasPermission) {
            return permissionsCheck.response;
        }

        try {
            const timerServiceClient = serviceClientFactory.getTimerManagementServiceClient();
            const timers = await timerServiceClient.getTimers();
            
            if (timers.totalCount === 0) {
                return responseBuilder
                    .speak('There are no active timers to cancel.')
                    .withShouldEndSession(true)
                    .getResponse();
            }

            const deletePromises = timers.timers.map(timer => 
                timerServiceClient.deleteTimer(timer.id)
            );
            await Promise.all(deletePromises);

            return responseBuilder
                .speak('Timer cancelled')
                .withShouldEndSession(true)
                .getResponse();

        } catch (error) {
            console.log('Error:', error);
            if (error.statusCode === 401) {
                return responseBuilder
                    .speak('Please enable Timer permissions in the Alexa app.')
                    .withAskForPermissionsConsentCard(PERMISSIONS)
                    .withShouldEndSession(true)
                    .getResponse();
            }
            return responseBuilder
                .speak('Sorry, there was an error cancelling the timer.')
                .withShouldEndSession(true)
                .getResponse();
        }
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say set timer to create a timer, or cancel timer to stop an existing timer. How can I help?';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .withShouldEndSession(true)
            .getResponse();
    }
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        return handlerInput.responseBuilder.getResponse();
    }
};

const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try saying set timer or cancel timer.';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const cleanupExistingTimers = async (handlerInput) => {
    try {
        const timerServiceClient = handlerInput.serviceClientFactory.getTimerManagementServiceClient();
        const timers = await timerServiceClient.getTimers();
        
        if (timers && timers.timers) {
            for (const timer of timers.timers) {
                try {
                    await timerServiceClient.deleteTimer(timer.id);
                } catch (error) {
                    console.log('Error deleting timer:', error);
                }
            }
        }
    } catch (error) {
        console.log('Error cleaning up timers:', error);
    }
};

const checkTimerPermissions = async (handlerInput) => {
    const { requestEnvelope, serviceClientFactory, responseBuilder } = handlerInput;
    const consentToken = requestEnvelope.context.System.apiAccessToken;

    if (!consentToken) {
        return {
            hasPermission: false,
            response: responseBuilder
                .speak('Please enable Timer permissions in the Alexa app.')
                .withAskForPermissionsConsentCard(PERMISSIONS)
                .getResponse()
        };
    }

    try {
        await serviceClientFactory.getTimerManagementServiceClient().getTimers();
        return {
            hasPermission: true
        };
    } catch (error) {
        console.log('Permission check error:', error);
        if (error.statusCode === 401) {
            return {
                hasPermission: false,
                response: responseBuilder
                    .speak('Please enable Timer permissions in the Alexa app.')
                    .withAskForPermissionsConsentCard(PERMISSIONS)
                    .getResponse()
            };
        }
        throw error;
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        SetTimerIntentHandler,
        CancelTimerIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        FallbackIntentHandler
    )
    .addErrorHandlers(ErrorHandler)
    .withApiClient(new Alexa.DefaultApiClient())
    .lambda();
